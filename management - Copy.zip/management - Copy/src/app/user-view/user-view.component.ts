import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../service/user.service';
import { User } from '../model/user';

@Component({
  selector: 'app-user-view',
  templateUrl: './user-view.component.html',
  styleUrls: ['./user-view.component.css']
})
export class UserViewComponent implements OnInit {
id:any;
user:User=new User();
  constructor(private _route:ActivatedRoute,private _router:Router,private _userservice:UserService) {
      this.id=this._route.snapshot.paramMap.get("id");
      this.getUserDetails();

   }

  ngOnInit() {
  }
  private getUserDetails()
  {
    this._userservice.GetUserByID(this.id).subscribe(
      result=>this.user=result
    )

  }

}
