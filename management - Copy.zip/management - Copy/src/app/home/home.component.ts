import { Component, OnInit } from '@angular/core';
import { UserService } from '../service/user.service';
import { User } from '../model/user';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
message:string;
userList:User[];
  constructor(private _user:UserService) { 
    this.message=_user.msg;
    this.GetUSer();
    console.log(this.userList)
  }

  GetUSer()
  {
    this._user.GetUserList().subscribe(
      result=>this.userList=result,
      
      )
      console.log(this.userList)
  }
  

  ngOnInit() {
    console.log(this.userList)
  }

}
