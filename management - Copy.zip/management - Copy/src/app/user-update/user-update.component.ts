import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from '../model/user';
import { UserService } from '../service/user.service';

@Component({
  selector: 'app-user-update',
  templateUrl: './user-update.component.html',
  styleUrls: ['./user-update.component.css']
})
export class UserUpdateComponent implements OnInit {

  id :any;
  user:User;
  constructor(private _route : ActivatedRoute,private _router:Router,private _userservice:UserService) { 
        this.id=this._route.snapshot.paramMap.get("id");

  }

  ngOnInit() {
  }
  private getUserDetails()
  {
    this._userservice.GetUserByID(this.id).subscribe(
      result=>this.user=result
    )

  }
  private  UpdateUser()
  {
    this._userservice.UpdateUser(this.user)
  }

}
