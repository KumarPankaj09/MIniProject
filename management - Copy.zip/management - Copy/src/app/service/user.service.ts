import { Injectable } from "@angular/core";
import {HttpClient}from '@angular/common/http'
import { Observable } from 'rxjs';
import { User } from '../model/user';


   @Injectable()

   export class UserService
   {
       msg:string="Hello JI"

       baseurl="https://jsonplaceholder.typicode.com/users/"
       constructor(private _http :HttpClient)
       {

       }
       GetUserList():Observable<User[]>
       {
            return this._http.get<User[]>(this.baseurl);
       }

       GetUserByID(id:number):Observable<User>
       {
           return this._http.get<User>(this.baseurl+id);
       }
       UpdateUser(_user: User) :Observable<User> 
       {
         
         return this._http.put<User>(this.baseurl,_user);

       }
       AddUser(_user:User):Observable<User>
       {
         return this._http.post<User>(this.baseurl,_user)
       }

       DeleteUser(_user):Observable<any>
      {
        return this._http.delete<User>(this.baseurl,_user)
      }

   }