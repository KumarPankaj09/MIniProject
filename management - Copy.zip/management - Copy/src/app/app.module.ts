import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import {RouterModule} from '@angular/router'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { UserAddComponent } from './user-add/user-add.component';
import { UserUpdateComponent } from './user-update/user-update.component';
import { UserDeleteComponent } from './user-delete/user-delete.component';
import { UserViewComponent } from './user-view/user-view.component';
import { UserService } from './service/user.service';
import { MainComponent } from './main/main.component';



@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    UserAddComponent,
    UserUpdateComponent,
    UserDeleteComponent,
    UserViewComponent,
    MainComponent
  
    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, 
    
    HttpClientModule
  ],
  providers: [UserService],
  bootstrap: [MainComponent]
})
export class AppModule { }
